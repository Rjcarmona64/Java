import java.util.Scanner;

public class MileageTrackerLinkedList {
   public static void main (String[] args) {
      Scanner scnr = new Scanner(System.in);

      // References for MileageTrackerNode objects
      MileageTrackerNode headNode;                                           
      MileageTrackerNode currNode;
      MileageTrackerNode lastNode;

      double miles;
      String date;
      int i;

      // Front of nodes list                                                                         
      headNode = new MileageTrackerNode();
      lastNode = headNode;

     // TODO: Scan the number of nodes
int count = scnr.nextInt();

// TODO: For the scanned number of nodes, scan
// in data and insert into the linked list
currNode = new MileageTrackerNode();
for (int j = 0; j < count; j++) {
miles = scnr.nextDouble();
date = scnr.next();
currNode = new MileageTrackerNode(miles, date);
if (j == 0) {
headNode = currNode;
lastNode = headNode;
}else{
headNode.insertAfter(currNode);
headNode = headNode.getNext();
}
}
// TODO: Call the printNodeData() method
// to print the entire linked list
for (int j = 0; j < count; j++) {
lastNode.printNodeData();
lastNode = lastNode.getNext();
}
   }
}