public class Artwork {
  // attributes

    private String title;

    private int yearCreated;

    private Artist artist;

    // default constructor, setting title to "None", year to 0, and initializing

    // artist using default constructor

    public Artwork() {

         title = "None";

         yearCreated = 0;

         artist = new Artist();

    }

   

    // constructor taking initial values for all fields

    public Artwork(String title, int yearCreated, Artist artist) {

         this.title = title;

         this.yearCreated = yearCreated;

         this.artist = artist;

    }

   

    //getter methods

   

    public String getTitle() {

         return title;

    }

    public int getYearCreated() {

         return yearCreated;

    }

   

    // method to print artwork info

    public void printInfo() {

         //printing artist details

         artist.printInfo();

         //printing artwork details

         System.out.println("Title: " + title + ", " + yearCreated);

    }

}
