public class Artist {
 private String artistName;

    private int birthYear;

    private int deathYear;

    // default constructor, setting artist name to "None", years to 0

    public Artist() {

         artistName = "None";

         birthYear = 0;

         deathYear = 0;

    }

    // constructor taking initial values for all fields

    public Artist(String artistName, int birthYear, int deathYear) {

         this.artistName = artistName;

         this.birthYear = birthYear;

         this.deathYear = deathYear;

    }

    // getter methods

    public String getName() {

         return artistName;

    }

    public int getBirthYear() {

         return birthYear;

    }

    public int getDeathYear() {

         return deathYear;

    }

    // method to print artist info

    public void printInfo() {

         // checking if death year is -1 and printing the details appropriately

         if (deathYear == -1) {

             System.out.println("Artist: " + artistName + ", born " + birthYear);

         } else {

             System.out.println("Artist: " + artistName + " (" + birthYear + "-"

                      + deathYear + ")");

         }

    }

}