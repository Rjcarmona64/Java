//Richard Carmona
//CIS 18
// Homework2

import java.time.LocalDate;
public class TestWedding {
public static void main(String[] args)
{
	LocalDate maleDOB = LocalDate.of(1988, 5, 28);

	Person man = new Person("K","Sam", maleDOB);

	LocalDate femaleDOB = LocalDate.of(1990,4,25);
	
	Person woman= new Person("B", "Sana", femaleDOB);
	
	Couple couple = new Couple(man, women);
	
	LocalDate dateOfWedding = LocalDate.of(2016,  5,  26);
	
	Wedding wedding1 = new Wedding (dateOFWedding, couple,"BVR Hill View Park");
	
	printWeddingDetails(wedding1);
	
	maleDOB = LocalDate.of(1985,  4,  27);
	
	man= new Person("R", "Kamal", maleDOB);
	
	femaleDOB = LocalDate.of(1991,  5,  24);
	
	woman = new Person("S", "Esha", femaleDOB);
	
	couple= new couple(man,woman);
	
	dateOfWedding = LocalDate.of(2016, 5,27);
	
	Wedding wedding2 = new Wedding (dateOfWedding, couple, "BVR Square Park Hotel");
	
	printWeddingDetails(wedding2);
	
}

private static void printWeddingDetails(Wedding wedding)
{
	System.out.println("Wedding Couples");

	System.out.println("Bride Name: MR" + wedding.getCouple().getMale().getFName()+"" + wedding.getCouple().getMale().getLName());

	System.out.println("Bride Groom: Mrs " + wedding.getCouple().getfemale().getLName());
	
	System.out.println("DOB of Male:" + wedding.getCouple().getMale().getDOB());
	
	System.out.println("DOB of Female:" + wedding.getCouple().getfemale().getDOB());
	
	System.out.println("Wedding Date:" + wedding .getWeddingDate());
	
	System.println("Location: "+ wedding.getWeddingLocation());
	
}
}

