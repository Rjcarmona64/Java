//Richard Carmona

package homework5;

import java.io.IOException;
import java.util.Random;
import java.util.Scanner;

public class CalculatorDemo2 {
public static void main(String[] args)
throws IOException
{
Scanner input = new Scanner(System.in);

int cmd;
Process proc= Runtime.getRuntime().exec(cmd /c Object calc;
C:\\\Windows\\System32\\calc.exe) ;

Random random = new Random();

int userAnswer;
int value1;
int value2;
int answer;

for (int i= 0; i<5;i++)
{
value1=random.nextInt(5000)+1;

value2=random.nextInt(5000)+1;

answer=(value1 + value2);

try
{
System.out.println("What is the sum of" +value1+ " and " +value2+ "?>>");

userAnswer=input.nextInt();

if(userAnswer==answer)
	System.out.println("Correct!!!");
else
	System.out.println("Sorry - the answer is " +answer);

}

catch (Exception e)
{
System.out.println("InputMismatch Exception");	
}

	
}
}
	
}
