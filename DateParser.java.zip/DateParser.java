import java.util.Scanner;

public class DateParser {
public static int getMonthAsInt(String monthString) {
int monthInt;

// Java switch/case statement
switch (monthString) {
case "January":
monthInt = 1;
break;
case "February":
monthInt = 2;
break;
case "March":
monthInt = 3;
break;
case "April":
monthInt = 4;
break;
case "May":
monthInt = 5;
break;
case "June":
monthInt = 6;
break;
case "July":
monthInt = 7;
break;
case "August":
monthInt = 8;
break;
case "September":
monthInt = 9;
break;
case "October":
monthInt = 10;
break;
case "November":
monthInt = 11;
break;
case "December":
monthInt = 12;
break;
default:
monthInt = 00;
}

return monthInt;
}

public static void main(String[] args) {
Scanner scnr = new Scanner(System.in);
String date;
int index, month_int;
String month, day, year;

// TODO: Read dates from input, parse the dates to find the one
// in the correct format, and output in mm/dd/yyyy format
while (true) {
// Take input from the user
date = scnr.nextLine();

// Check if entered date ==-1 then exit
if (date.equals("-1") == true)
break;
// Check if date contains "," so its in correct format
index = date.indexOf(",");
if (index == -1)
continue;

// Extract month, day and year based on position of "," using substring() function
String month_date = date.substring(0, index);
month = month_date.split(" ")[0];
day = month_date.split(" ")[1];
year = date.substring(index + 2);

// Call the function to get month in integer format
month_int = getMonthAsInt(month);

// Print the date in required format
System.out.println(month_int + "/" + day + "/" + year);
}

}
}