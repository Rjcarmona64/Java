//Richard Carmona
// Homework 8 #8

package homework6;

import java.awt.FlowLayout;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.ButtonGroup;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JTextField;

public class JInsurance extends JFrame implements ItemListener{
	final int HMO_Cost=200;
	
	final int PPO_Cost=600;
	
	final int DENTAL_CARE_COST=75;
	
	final int VISION_CARE_COST=20;
	
	JCheckBox hmoBox= new JCheckBox("HMO cost $"+HMO_Cost);
	
	JCheckBox ppoBox = new JCheckBox("PPO cost $"+PPO_Cost);
	
	JCheckBox dentalBox = new JCheckBox("Dental Care $"+DENTAL_CARE_COST,false);
	
	JCheckBox visionBox = new JCheckBox("Vision Care $"+VISION_CARE_COST,false);
	
	JTextField descriptionField= new JTextField(20);
	
	public JInsurance()
	{
		setTitle("Insurance Calculator");
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setLayout(new FlowLayout());
		
		ButtonGroup insuranceBtnGrp = new ButtonGroup();
		
		insuranceBtnGrp.add(hmoBox);
		
		insuranceBtnGrp.add(ppoBox);
		
		add(dentalBox);
		
		add(visionBox);
		
		dentalBox.addItemListener(this);
		
		visionBox.addItemListener(this);
		
		descriptionField.setText("$0");
		
		add(descriptionField);
	}
public void itemStateChanged(ItemEvent e) {
	
	Object source = e.getSource();
	
	int select= e.getStateChange();
	
	if(source==hmoBox) {
		if(select==ItemEvent.SELECTED)
			descriptionField.setText("HMO $"+HMO_Cost);
		
		else descriptionField.setText("");
		
	}
	
	else if(source == ppoBox) {
		if(select==ItemEvent.SELECTED)
			descriptionField.setText("PPO $"+PPO_Cost);
		
		else descriptionField.setText("");
	}
	else if(source == dentalBox) {
		if(select==ItemEvent.SELECTED)
			descriptionField.setText("Dental Care $"+DENTAL_CARE_COST);
		
		else descriptionField.setText("");
	}
	
	else if(source == visionBox) {
		if(select==ItemEvent.SELECTED)
			descriptionField.setText("Vision Care $"+VISION_CARE_COST);
		
		else descriptionField.setText("");
	}
	
}

public static void main(String[] args) {
	
	final int WIDTH=250;
	
	final int HEIGHT=250;
	
	JInsurance insuranceFrame= new JInsurance();
	
	insuranceFrame.setSize(WIDTH,HEIGHT);
	
	insuranceFrame.setVisible(true);
}
	
}