//Richard Carmona

public class Recording {

	private String title;
	
	private String artist;
	
	private int seconds; 
	
	public Recording()
	{
		title="";
		
		artist= "";
		
		seconds-= 0;	
	}
	
	public void setTitle(String title)
	{
		this.title=title;
		
	}
	
	public void setArtist(String artist)
	{
		this.artist=artist;
		
	}
	public void setSeconds(int seconds)
	{
		this.seconds=seconds;
		
	}
	public String getTitle()
	{
		return title;
	}
	
	public String getArtist()
	{
		return artist; 
		
	}
	
	public int getSeconds()
	{
		return seconds;
	}
	
}
