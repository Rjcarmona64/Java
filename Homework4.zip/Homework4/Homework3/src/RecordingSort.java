//Richard Carmona

import java.util.Scanner;

public class RecordingSort {
public static void main(String[] args)
{
Scanner scanner = new Scanner(System.in);

Recording[] recordings = new Recording[5];

recordings[0]= new Recording();
recordings[0].setArtist("Weird Al");
recordings[0].setTitle("Dare to be stupid");
recordings[0].setSeconds(290);

recordings[1]= new Recording();
recordings[1].setArtist("Modana");
recordings[1].setTitle("Like a dancer");
recordings[1].setSeconds(250);

recordings[2]= new Recording();
recordings[2].setArtist("Jackson");
recordings[2].setTitle("Thriller");
recordings[2].setSeconds(260);

recordings[3]= new Recording();
recordings[3].setArtist("Jackson");
recordings[3].setTitle("Bad");
recordings[3].setSeconds(270);

recordings[4]= new Recording();
recordings[4].setArtist("Jackson");
recordings[4].setTitle("Xscape");
recordings[4].setSeconds(280);

System.out.println("Sorting feilds");
System.out.println("1. Artist");
System.out.println("2. Title");
System.out.println("3. Seconds");
System.out.println("Enter your choice 1-3");

int choice = scanner.nextInt();

switch (choice)
{
	case 1:
		sortByArtist(recordings);
		print(recordings);
		break;
		
	case 2:
		sortByTitle(recordings);
		print(recordings);
		break;
		
	case 3:
		sortBySeconds(recordings);
		print(recordings);
		break;
}
	
}

private static void print(Recording[] recordings)
{
System.out.printf("%-20s%-20%-10s\n","Artist", "Artist","Seconds");

for (int index=0; index<recordings.length; index++)
{
	System.out.printf("%-20s%-20%-5s\n",
			recordings[index].getArtist(),
			recordings[index].getTitle(),
			recordings[index].getSeconds());
	
}
	
}

private static void sortBySeconds
(Recording[] recordings)
{
	Recording temp;
	
	for (int i = 0; i<recordings.length-1;i++)
	{
		for(int j = 0; j<recordings.length-1;j++)
		{
			if(recordings[j].getSeconds()>recordings[j+1].getSeconds())
			{
				temp=recordings[j];
				recordings[j]=recordings[j+1];
				recordings[j+1]=temp;
				
				
			}
					
		}
	}
}

private static void sortByTitle
(Recording[] recordings)
{
	Recording temp;
	
	for (int i = 0; i<recordings.length-1;i++)
	{
		for(int j = 0; j<recordings.length-1;j++)
		{
			if(recordings[j].getTitle().compareTo(recordings[j+1].getTitle())>0)
			{
				temp=recordings[j];
				recordings[j]=recordings[j+1];
				recordings[j+1]=temp;
				
				
			}
					
		}
	}
}

private static void sortByArtist
(Recording[] recordings)
{
	Recording temp;
	
	for (int i = 0; i<recordings.length-1;i++)
	{
		for(int j = 0; j<recordings.length-1;j++)
		{
			if(recordings[j].getArtist().compareTo(recordings[j+1].getArtist())>0)
			{
				temp=recordings[j];
				recordings[j]=recordings[j+1];
				recordings[j+1]=temp;
				
				
			}
					
		}
	}
}

}
