// Richard Carmona
//1/18/18
// Homework3

import java.util.Scanner;

import java.util.Random;

public class Count21 {

	public static void main(String[] args)
	
	{
		
		Random random = new Random();
		
		int total = 0;
		
		int computer; 
		
		Scanner scanner = new Scanner(System.in);
		
		int user; 
		
		while(total <=21)
			{
			computer = random.nextInt(3)+1;
			
			total += computer;
			
			if(total> 21)
				{
				System.out.println("Computer total: " +total);
				
				System.out.println("Computer Loss Game");
				
				break;
				}
			do 
			{
				System.out.println("Enter a 1, 2, or 3 -->");
				
				user = scanner.nextInt();
				
				total += user;
				
				if(user < 1 || user > 3)
				{
					System.out.println("Enter only 123");
				}
			
			}
			
			while ((user < 1 || user >3));
			
			if(total>21)	
			{
				System.out.println("Total: " +total);
				
				System.out.println("You lose");
				
				break;
			}
			}	
		}
	}
	

