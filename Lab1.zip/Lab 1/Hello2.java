//filename Hello2.java
//written by Richard Carmona
//written on 1/3/18

public class Hello2
/*This class demenstrates the use of the printIn() method to print the message Hell, world!*/
{
   public static void main(String[] args)
   {
      System.out.println("Hello");
      System.out.println("This is a test");
   }
}
