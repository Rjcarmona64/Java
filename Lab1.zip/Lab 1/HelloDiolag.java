//filename HelloDiolag.java
//written by Richard Carmona
//written on 1/3/18

import javax.swing.JOptionPane;

public class HelloDiolag
{
   public static void main(String[] args)
   {
      JOptionPane.showMessageDiolag(null, "Hello, world!");
   }
}
