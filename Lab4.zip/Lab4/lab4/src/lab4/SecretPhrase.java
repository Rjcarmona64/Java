//Richard Carmona


package lab4;

import java.util.Scanner;
public abstract class SecretPhrase{

	public static int countStars(String str)
	{
		
		int count = 0;
		
		for(int i = 0; i < str.length(); i++){
			
		if(str.charAt(i) == '*') count++;
		}
		
 return count;
�� }
	public static void main(String args[])
	{
		String phrase = "Go Team", incomplete = "G* T***";
		
		String temp = incomplete;
		
		int count = 0;
		
		Scanner in = new Scanner(System.in);
		while(countStars(incomplete) != 0)
		{
			
			System.out.println(incomplete);
			
			System.out.print("Enter a character: ");
			
			char t = in.next().charAt(0);
			
			for(int i = 0; i < incomplete.length(); i++)
			{
				
				if(incomplete.charAt(i) == '*' && phrase.charAt(i) == t)
				{
					incomplete = incomplete.substring(0, i) + t + incomplete.substring(i + 1);
					}
}
if(temp.equals(incomplete)) System.out.println("Character " + t + " not found.");

else System.out.print("After replacing " + t + ", new string: ");

temp = incomplete;

count++;
}
System.out.println(incomplete);
System.out.println("Congratulations! You have successfully guessed the string in " + count + " tries");
�� }
}
