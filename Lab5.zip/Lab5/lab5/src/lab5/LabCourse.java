//Richard Carmona

package lab5;

class LabCourse extends CollegeCourse
{
public LabCourse(String d, int c, int cr)
{
super(d,c,cr);
fee = fee + 50;
}

public void display()
{
System.out.println("Course is a lab course");
System.out.println("Department is " + department);
System.out.println("Course number is " + course_number);
System.out.println("credits are " + credits);
System.out.println("Fee is " + fee);
}
}
