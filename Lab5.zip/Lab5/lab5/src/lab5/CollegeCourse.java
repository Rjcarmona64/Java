package lab5;

import java.util.*;

class CollegeCourse
{
protected String department; 
protected int course_number;
protected int credits; 
protected double fee; 
public CollegeCourse(String d, int c, int cr)
{
department = d;
course_number = c;
credits = cr;
fee = credits*120;
}

public void display()
{
System.out.println("Department is " + department);
System.out.println("Course number is " + course_number);
System.out.println("credits are " + credits);
System.out.println("Fee is " + fee);
}
}
