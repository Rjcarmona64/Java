//Richard Carmona

package lab5;

import java.util.Scanner;

public class UseCourse
{
	public static void main(String[] args)
{
		Scanner in = new Scanner(System.in);

		System.out.println("Enter course Department :");
		String d = in.next();
		System.out.println("Enter course Number :");
		int c = in.nextInt();
		System.out.println("Enter course Credits :");
		int cr = in.nextInt();

if(d.equals("BIO") || d.equals("CHM") || d.equals("CIS") || d.equals("PHY"))
	{
		LabCourse LC = new LabCourse(d, c, cr);
		LC.display();
		}

	else
	{
		CollegeCourse CC = new CollegeCourse(d, c, cr);
		CC.display();
�� }

�� }
}