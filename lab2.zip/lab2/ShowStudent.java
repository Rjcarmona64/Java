package lab2;

public class ShowStudent {
		{
		public static void main(String[] args)
		{
			Student student = new student();
			student.setID(369);
			student.setCreditHours(4);
			student.setPoints(26);
			student.computerGradePointAverage();
			student.displayStudent();
		}
		}

	public class Student {

		private int ID;
		private double creditHours;
		private int points; 
		private double gradePointAverage; 


	public void setID(int id)
	{
	ID = id;	
	}

	public void setCreditHours(double hrs)
	{
		creditHours = hrs;
		}
	public void setPoints(int pts)
	{
		points=pts;
	}
	public void computerGradePointAverage()
	{
	gradePointAverage= points/ creditHours;	
	}
	
	public void displayStudent()
	{
	System.out.println("Student ID: " + ID);
	System.out.println("Number of credit hours earned: " + creditHours);
	System.out.println("Number of points earned: " + points);
	System.out.println("Grade point average: " + gradePointAverage);
		
	}
	}
}
