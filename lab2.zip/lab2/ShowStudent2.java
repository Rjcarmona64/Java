package lab2;

import lab3.ShowStudent.Student;

public class ShowStudent {
	{
	public static void main(String[] args)
	{
		Student student = new student();
		student.setID(369);
		student.setCreditHours(4);
		student.setPoints(26);
		student.computerGradePointAverage();
		student.displayStudent();
	}
	}

public class Student {

	private int ID;
	private double creditHours;
	private int points; 
	private double gradePointAverage; 

public Student()
{
ID= 9999;
creditHours= 3;
points=12;
}
public int getID()
{
return ID;	
}
public double getCreditHours()
{
return creditHours;	
}
public int getPoint()
{
return points;	
}
public void setID(int id)
{
ID = id;	
}

public void setCreditHours(double hrs)
{
	creditHours = hrs;
	}
public void setPoints(int pts)
{
	points=pts;
}
public void computerGradePointAverage()
{
gradePointAverage= points/ creditHours;	
}

public void displayStudent()
{
System.out.println("Student ID: " + ID);
System.out.println("Number of credit hours earned: " + creditHours);
System.out.println("Number of points earned: " + points);
System.out.println("Grade point average: " + gradePointAverage);
	
}
}
}

