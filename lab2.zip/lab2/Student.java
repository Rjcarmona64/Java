/* richard carmona
1//10/18
LAB2
*/

package lab2;

public class Student {

	private int ID;
	private double creditHours;
	private int points; 
	private double gradePointAverage; 


public void setID(int id)
{
ID = id;	
}

public void setCreditHours(double hrs)
{
	creditHours = hrs;
	}

public void computerGradePointAverage()
{
gradePointAverage= points/ creditHours;	
}

public void displayStudent()
{
System.out.println("Student ID: " + ID);
System.out.println("Number of credit hours earned: " + creditHours);
System.out.println("Number of points earned: " + points);
System.out.println("Grade point average: " + gradePointAverage);
	
}

}
