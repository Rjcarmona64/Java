public class Dog extends Pet {
   private String dogBreed;

   public void setBreed(String userBreed) {
      dogBreed = userBreed;
   }

   public String getBreed() {
      return dogBreed;
   }
}
