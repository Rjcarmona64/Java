//filename MinutesConversion.java
//written by Richard Carmona
//written on 1/3/18

import java.util.Scanner;

public class MinutesConversion
{
public static void main(String[] args)
}

Scanner scanner= new Scanner(System.in);

int minutes; 

System.out.print("Enter the number of minutes.");

minutes= scanner.nextInt();

double hours= (double) minutes/ 60;

double days= (double) minutes/ (60*24);

System.out.printf("%d minutes equals %.3f" + "hours and eaquals %.3f days.");

}


