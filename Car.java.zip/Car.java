public class Car {
   private int modelYear; 
   // TODO: Declare purchasePrice field (int)
private int purchasePrice;
   private int currentValue;
   
   public void setModelYear(int userYear){
      modelYear = userYear;
   }
   
   public int getModelYear() {
      return modelYear;
   }
   
     public int getPurchasePrice() {
        return purchasePrice;
    }

    public void setPurchasePrice(int purchasePrice) {
        this.purchasePrice = purchasePrice;
    }

    public int getCurrentValue() {
        return currentValue;
    }

   
   public void calcCurrentValue(int currentYear) {
      double depreciationRate = 0.15;
      int carAge = currentYear - modelYear;
      
      // Car depreciation formula
      currentValue = (int) 
         Math.round(purchasePrice * Math.pow((1 - depreciationRate), carAge));
   }
   
      public void printInfo() {
        System.out.println("Car's information:");
        System.out.println("   Model year: " + modelYear);
        System.out.println("   Purchase price: " + purchasePrice);
        System.out.println("   Current value: " + currentValue);
    }
   
}